import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "retail_sales.csv", parse_dates=["date"])
df["month"] = df["date"].dt.to_period("M").astype(str)

summary = pd.DataFrame([{
    "total_revenue_kes": round(df.revenue_kes.sum(),2),
    "total_profit_kes": round(df.profit_kes.sum(),2),
    "total_units": int(df.quantity.sum()),
    "average_transaction_value_kes": round(df.revenue_kes.mean(),2),
    "profit_margin_pct": round(df.profit_kes.sum()/df.revenue_kes.sum()*100,2)
}])
summary.to_csv(ROOT/"analysis"/"overall_summary.csv",index=False)

product = df.groupby(["product","category"],as_index=False).agg(
    revenue_kes=("revenue_kes","sum"), profit_kes=("profit_kes","sum"), units=("quantity","sum"))
product["profit_margin_pct"]=(product.profit_kes/product.revenue_kes*100).round(2)
product.sort_values("revenue_kes",ascending=False).to_csv(ROOT/"analysis"/"product_performance.csv",index=False)

monthly = df.groupby("month",as_index=False).agg(
    revenue_kes=("revenue_kes","sum"),profit_kes=("profit_kes","sum"))
monthly.to_csv(ROOT/"analysis"/"monthly_performance.csv",index=False)

channel = df.groupby("channel",as_index=False).agg(
    revenue_kes=("revenue_kes","sum"),profit_kes=("profit_kes","sum"),units=("quantity","sum"))
channel.to_csv(ROOT/"analysis"/"channel_performance.csv",index=False)

plt.figure(figsize=(8,5))
plt.bar(product.sort_values("revenue_kes",ascending=False)["product"],
        product.sort_values("revenue_kes",ascending=False)["revenue_kes"])
plt.xticks(rotation=35,ha="right"); plt.title("Revenue by Product"); plt.ylabel("Revenue (KES)")
plt.tight_layout(); plt.savefig(ROOT/"visualizations"/"revenue_by_product.png",dpi=160); plt.close()

plt.figure(figsize=(8,5))
plt.plot(monthly["month"],monthly["revenue_kes"],marker="o")
plt.xticks(rotation=35); plt.title("Monthly Revenue Trend"); plt.ylabel("Revenue (KES)")
plt.tight_layout(); plt.savefig(ROOT/"visualizations"/"monthly_revenue.png",dpi=160); plt.close()
