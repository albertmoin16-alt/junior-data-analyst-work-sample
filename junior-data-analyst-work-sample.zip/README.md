# Kenya Retail Sales Analysis

## Project Overview
A portfolio project demonstrating practical junior data analyst skills through analysis of a six-month sample retail sales dataset.

**Dataset note:** The data is synthetic and created for portfolio/demo purposes; it does not represent a real company.

## Business Questions
- Which products generate the most revenue and profit?
- How does revenue change over time?
- Which sales channels perform best?
- What actions could management take from the results?

## Tools
Python • Pandas • Matplotlib • CSV • GitHub

## Dataset
300 sample transactions from January–June 2025.

Key fields include date, product, category, region, channel, quantity, unit price, discount, revenue, cost and profit.

## Analysis Workflow
1. Load transaction data with Pandas.
2. Create a monthly time field.
3. Calculate revenue, profit, units, average transaction value and margin.
4. Aggregate performance by product, month and channel.
5. Export summary tables.
6. Create visualizations.

## Key Findings
Run `analysis/analyze_sales.py` to reproduce the included summary tables and charts from the dataset.

The analysis identifies top-performing products, monthly trends, channel contribution and profitability opportunities.

## Recommendations
- Prioritize high-revenue and high-margin products when planning stock.
- Review discounts where they reduce margin without sufficient volume benefit.
- Compare channels using profit as well as revenue.
- Monitor monthly revenue and profit together for better decision-making.

## How to Run
```bash
pip install -r requirements.txt
python analysis/analyze_sales.py
```

## Project Structure
```text
junior-data-analyst-work-sample/
├── data/
│   ├── retail_sales.csv
│   └── data_dictionary.csv
├── analysis/
│   ├── analyze_sales.py
│   ├── overall_summary.csv
│   ├── product_performance.csv
│   ├── monthly_performance.csv
│   └── channel_performance.csv
├── visualizations/
│   ├── revenue_by_product.png
│   └── monthly_revenue.png
├── README.md
├── requirements.txt
└── .gitignore
```

## Skills Demonstrated
Data Analysis • Data Cleaning • KPI Analysis • Exploratory Data Analysis • Data Visualization • Business Insights • Python • Pandas • GitHub
